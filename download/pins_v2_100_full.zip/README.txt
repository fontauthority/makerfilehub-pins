Pinterest pins - batch v2 (100 pins)
=====================================
images/001.jpg ... 100.jpg
  Номер файла = номер строки в pinterest_100_v2.csv (строка 1 -> 001.jpg).
  Размеры: 55 x 768x1376 (9:16) и 45 x 896x1200 (3:4). Ничего не кропалось.

pinterest_100_v2.csv
  Готовый файл загрузки Pinterest (8 колонок bulk upload), 100 строк.
  Title / Description / Link уникальны, Publish date пустая.

pins_list.csv
  То же плюс колонки "Image file" и "Format" - для сверки картинки со строкой.

Media URL картинок (уже работает, 200 OK):
  https://fontauthority.github.io/makerfilehub-pins/pins_v2/NNN.jpg

Загрузка: Pinterest -> Создать -> Загрузить несколько пинов -> CSV.
Колонку Publish date можно оставить пустой (публикация сразу) или вписать даты
не более чем на 14 дней вперёд. Доски из колонки "Pinterest board" должны
существовать в аккаунте, иначе строка не загрузится.
